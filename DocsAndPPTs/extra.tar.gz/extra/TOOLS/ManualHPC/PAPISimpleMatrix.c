/*
 * A simple example of the use of the high level PAPI_flops call.
 * PAPI_flops measures elapsed time, process time, floating point
 * instructions and MFLOP/s for code bracketted by calls to this routine.
 * For the following matrix multiply you should get 2*(INDEX^3) flpins 
 * on Intel Pentium processors.
 */

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <memory.h>
#include <malloc.h>
#include "papi.h"
#include <sys/time.h>

#define INDEX 1000

static void test_fail(char *file, int line, char *call, int retval);

/* Get actual CPU time in seconds */
float gettime() {
    return ((float) PAPI_get_virt_usec()*1000000.0);
}


int main(int argc, char **argv) {
    //extern void dummy(void *);
    float t0, t1;
    long_long values[2];
    float matrixa[INDEX][INDEX], matrixb[INDEX][INDEX], mresult[INDEX][INDEX];
    int events[2] = {PAPI_TOT_CYC, PAPI_L3_TCM}, ret;
    int retval;
    int i, j, k;

    if (PAPI_num_counters() < 2) {
        fprintf(stderr, "No hardware counters here, or PAPI not supported.\n");
        exit(1);
    }
    
    /* Check to see if the preset, PAPI_TOT_INS, exists */
    retval = PAPI_query_event( PAPI_TOT_CYC );
    if (retval != PAPI_OK) {
        fprintf (stderr,"No instruction counter? How lame.\n");
        exit(1);
    }
    /* Initialize the Matrix arrays */
    for (i = 0; i < INDEX * INDEX; i++) {
        mresult[0][i] = 0.0;
        matrixa[0][i] = matrixb[0][i] = rand()*(float) 1.1;
    }

    /* Setup PAPI library and begin collecting data from the counters */
    t0 = gettime();
    if ((ret = PAPI_start_counters(events, 2)) != PAPI_OK) {
        fprintf(stderr, "PAPI failed to start counters: %s\n", PAPI_strerror(ret));
        exit(1);
    }
    /* Matrix-Matrix multiply */
    for (i = 0; i < INDEX; i++)
        for (j = 0; j < INDEX; j++)
            for (k = 0; k < INDEX; k++)
                mresult[i][j] = mresult[i][j] + matrixa[i][k] * matrixb[k][j];

    /* Collect the data into the variables passed in */
    if ((ret = PAPI_read_counters(values, 2)) != PAPI_OK) {
        fprintf(stderr, "PAPI failed to read counters: %s\n", PAPI_strerror(ret));
        exit(1);
    }
    t1 = gettime();

    //printf("Total software flops = %f\n", (float) TOT_FLOPS);
    printf("Total CPU cycles = %lld\n", values[1]);
    printf("MFlop/s = %f\n", (t1 - t0));
    printf("L2 data cache misses is %lld\n", values[0]);
    PAPI_shutdown();
    exit(0);
}

static void test_fail(char *file, int line, char *call, int retval) {
    printf("%s\tFAILED\nLine # %d\n", file, line);
    if (retval == PAPI_ESYS) {
        char buf[128];
        memset(buf, '\0', sizeof (buf));
        sprintf(buf, "System error in %s:", call);
        perror(buf);
    } else if (retval > 0) {
        printf("Error calculating: %s\n", call);
    } else {
        printf("Error in %s: %s\n", call, PAPI_strerror(retval));
    }
    printf("\n");
    exit(1);
}