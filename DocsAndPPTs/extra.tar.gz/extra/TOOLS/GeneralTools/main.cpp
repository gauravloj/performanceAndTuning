/* 
 * File:   main.cpp
 * Author: mohit
 *
 * Created on 17 April, 2017, 11:38 AM
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    return 0;
}

